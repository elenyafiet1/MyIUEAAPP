# 📝 Manual Testing Report

## 📌 Overview

This report documents the results of manual testing for the app.

## 🔹 Test Cases

| Test Case ID | Feature         | Steps                                      | Expected Result                  | Actual Result              | Status  |
| ------------ | --------------- | ------------------------------------------ | -------------------------------- | -------------------------- | ------- |
| TC001        | Login           | Enter valid email & password → Click login | User logs in successfully        | ✅ Works as expected       | ✅ Pass |
| TC002        | Login           | Enter wrong password → Click login         | Error message appears            | ✅ error message displayed | ✅ Pass |
| TC003        | Form Validation | Submit empty form                          | "Field required" message appears | ✅ Works correctly         | ✅ Pass |
| TC004        | Button Click    | Click "Save" button                        | Data is saved........            | ✅ App works               | ✅ Pass |

## 🛠 Bugs Found

- ❌ **Issue:** Labels do not disappear when entering credentials (TC002).

## 🚀 Suggestions

- We can improve the performane of the app by adding more features.
