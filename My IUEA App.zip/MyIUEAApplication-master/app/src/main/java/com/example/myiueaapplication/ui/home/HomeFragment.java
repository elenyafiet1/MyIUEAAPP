package com.example.myiueaapplication.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.myiueaapplication.databinding.FragmentHomeBinding;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private FirebaseFirestore db;
    private TextInputEditText textInput;
    private Button saveButton;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Initialize Firebase Firestore
        db = FirebaseFirestore.getInstance();

        // Find views from binding
        textInput = binding.textInput;
        saveButton = binding.saveButton;

        // Set button click listener
        saveButton.setOnClickListener(v -> saveTextToFirestore());

        return root;
    }

    private void saveTextToFirestore() {
        String text = textInput.getText().toString().trim();

        if (text.isEmpty()) {
            Toast.makeText(getContext(), "Please enter text", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> textEntry = new HashMap<>();
        textEntry.put("text", text);

        db.collection("texts")  // Creates "texts" collection dynamically
                .add(textEntry)  // Creates a new document with an auto-generated ID
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(getContext(), "Text saved successfully", Toast.LENGTH_SHORT).show();
                    textInput.setText("");  // Clear input after saving
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getContext(), "Failed to save text", Toast.LENGTH_SHORT).show();
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
